import { Component, OnInit } from "@angular/core";

@Component({
    selector: "project-sidebar",
    templateUrl: "./sidebar.component.html",
    styleUrls: ["./sidebar.component.scss"]
})
export class SidebarComponent implements OnInit {
    menu: any = [];

    constructor() {}

    ngOnInit(): void {
        this.menu.push({
            iconName: "dashboard",
            displayName: "Gestão de projetos",
            children: [
                {
                    iconName: "dashboard",
                    displayName: "Board",
                    route: "/board"
                }
            ]
        });

        // this.menu.push({
        //     iconName: "desktop_windows",
        //     displayName: "Menu com 1 nível",
        //     children: [
        //         {
        //             iconName: "ballot",
        //             displayName: "Teste 1"
        //         }
        //     ]
        // });
    }
}
