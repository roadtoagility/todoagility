import { Component, OnDestroy, OnInit } from '@angular/core';
import {MediaObserver, MediaChange} from '@angular/flex-layout'
import  {Subscription} from 'rxjs'

@Component({
  selector: 'project-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss']
})
export class MainLayoutComponent implements OnInit, OnDestroy {

  title = 'flex-tutorial';
  mediaSub: Subscription = new Subscription;
  devicesXs: boolean = false;

  constructor(public mediaObserver:MediaObserver) { }


  ngOnInit(): void {
    this.mediaSub = this.mediaObserver.media$.subscribe((result:MediaChange) =>{
      console.log(result.mqAlias);
      this.devicesXs = result.mqAlias === 'xs' ? true : false;
    })
  }

  ngOnDestroy(): void {
    this.mediaSub.unsubscribe();
  }

}
