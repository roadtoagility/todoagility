import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'project-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.scss']
})
export class BoardComponent implements OnInit {

  projects: any = [];

  constructor() { }

  ngOnInit(): void {

    this.projects.push({
      id: 1,
      name: "Projeto de rodovias",
      dataInicio: "02/11/2020",
      manager: "Douglas Ramalho"
    },
    {
      id: 2,
      name: "Revitalização Park Sul",
      dataInicio: "15/11/2020",
      manager: "Matheus dos Santos"
    },
    {
      id: 2,
      name: "Revitalização Park Sul",
      dataInicio: "15/11/2020",
      manager: "Matheus dos Santos"
    },
    {
      id: 2,
      name: "Revitalização Park Sul",
      dataInicio: "15/11/2020",
      manager: "Matheus dos Santos"
    });
  }
}
